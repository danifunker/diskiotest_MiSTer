DiskIOTest scratch image
========================

scratch_1024M.img is a 1024 MB file of zeros for the DiskIOTest core and
for tools/diskio_bench.py.  WRITE TESTS OVERWRITE IT - never point the
benchmark at an image you care about.

1. Extract this archive onto the root of the MiSTer SD card, so the file
   ends up as /media/fat/games/DiskIOTest/scratch_1024M.img.
   Make sure your extractor really writes the zeros (a "sparse" extraction
   would give unrepresentative write numbers); normal unzip does.
2. Start DiskIOTest, OSD -> Mount scratch image -> pick the file.
   The cycle starts one second after the mount and the mount is remembered.

The native script uses the same file:
   cd /media/fat/games/DiskIOTest && python3 diskio_bench.py scratch_1024M.img
